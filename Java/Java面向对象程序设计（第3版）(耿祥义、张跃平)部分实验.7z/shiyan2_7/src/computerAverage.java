//computerAverage.java
public interface computerAverage {
//接口
    public double average( double x[ ]);
}
