abstract class T {
    public abstract int f(int a, int b);
}

