
//Goods.java
public class Goods {
    boolean isDanger;
    String name;
    public void setIsDanger( boolean boo){
        isDanger = boo;
    }
    public boolean isDanger(){
        return isDanger;
    }
    public void setName( String s){
        name =s;
    }
    public String getName() {
        return name;
    }
}
