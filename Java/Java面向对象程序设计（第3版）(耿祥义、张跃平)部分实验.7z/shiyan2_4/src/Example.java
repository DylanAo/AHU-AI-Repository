//Example.java
public class Example {
public static void main( String args[ ]){
ChinaPeople Chinapeople = new ChinaPeople();
AmericanPeople americanPeople = new AmericanPeople();BeijingPeople beijingPeople = new BeijingPeople( );
Chinapeople.speakHello( );
americanPeople.speakHello();beijingPeople.speakHello();
Chinapeople.averageHeight();americanPeople.averageHeight( );
beijingPeople.averageHeight( );Chinapeople. averageWeight( );
americanPeople.averageWeight();beijingPeople.averageWeight( );Chinapeople.chinaGongfu( );
americanPeople.americanBoxing( );beijingPeople. beijingOpera( ) ;
beijingPeople.chinaGongfu();}}