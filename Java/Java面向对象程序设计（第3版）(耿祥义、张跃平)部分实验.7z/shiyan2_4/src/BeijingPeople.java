public class BeijingPeople extends ChinaPeople {
    @Override
    public void averageHeight() {
        System.out.println("北京人的平均身高：172.5厘米");
    }

    @Override
    public void averageWeight() {
        System.out.println("北京人的平均体重：70千克");
    }

    public void beijingOpera() {
        System.out.println("花脸、青衣、花旦和老生");
    }
}
