
import javax.swing.*;
import static javax.swing.JFrame.*; //引入JFrame的静态常量
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.util.*;


class chat{
    public static void main(String args[]) {
    	 
    	MyExtendsJFrame frame=new MyExtendsJFrame();//创建聊天程序窗口
    	frame.run();
    	       
	}
}

