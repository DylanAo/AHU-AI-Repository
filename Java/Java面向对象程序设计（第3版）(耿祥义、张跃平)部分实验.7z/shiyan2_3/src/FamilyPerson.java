public class FamilyPerson {
    static String surname;
    String name;
    public static void setSurname( String s){
        surname =s;}

    public void setName( String s) {name =s;}}
