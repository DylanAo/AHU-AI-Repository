public class MainClass{
    public static void main(String args[]){
        School school=new School("创新大学");
        school.showNews();
    }
}
