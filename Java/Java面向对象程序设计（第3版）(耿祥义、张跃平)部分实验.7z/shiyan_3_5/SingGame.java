import com.sun.jdi.connect.Connector;

public class SingGame {
    public static  void main(String args[]){
        Line line=new Line();
        line.givePersonScore();
    }
}
