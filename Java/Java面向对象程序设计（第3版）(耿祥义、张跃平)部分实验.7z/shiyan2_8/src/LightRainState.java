public class LightRainState implements  WeatherState{
    public  void showState(){
        System.out.print("小雨.");
    }
}
