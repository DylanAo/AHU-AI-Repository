public class CloudyDayState implements WeatherState{
    public  void showState(){
        System.out.print("少云，有时晴.");
    }
}
