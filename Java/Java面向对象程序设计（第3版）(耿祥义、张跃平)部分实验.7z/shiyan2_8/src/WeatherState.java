public interface WeatherState {
    public void showState();
}
