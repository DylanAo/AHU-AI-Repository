public class HeavyRainState implements  WeatherState{
    public  void showState(){
        System.out.print("大雨.");
    }
}
