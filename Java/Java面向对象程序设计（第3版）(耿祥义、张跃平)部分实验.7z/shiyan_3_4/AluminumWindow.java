public class AluminumWindow extends  Window{
    public String getMaterial(){
        return "铝合金窗户";
    }
}
