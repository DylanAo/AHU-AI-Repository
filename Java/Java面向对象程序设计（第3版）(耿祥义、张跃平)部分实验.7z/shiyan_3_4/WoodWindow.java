public class WoodWindow extends Window{
        public String getMaterial(){
            return"木制窗户";
        }
}

